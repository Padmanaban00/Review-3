package com.review1.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.review1.demo.model.Customer;
import com.review1.demo.model.Supermarket;

import com.review1.demo.Service.Review1Service;

@RestController
public class Review1Controller {
	@Autowired
	Review1Service a;
	@GetMapping(value="/getid")
	public List<Supermarket> getAllReview1Model()
	{
		return a.getAllReview1Models();
		
	}
	@PostMapping(value="/postid")
	public Supermarket saveReview1Model(@RequestBody Supermarket b) 
	{
		return a.saveReview1Model(b);
	}
	@PutMapping(value="/putvalue")
	public Supermarket updateReview1Model(@RequestBody Supermarket b)
	{
		
		return a.saveReview1Model(b);
	}
	@DeleteMapping("/deleid/{id}")
	public String deleteReview1Model(@PathVariable("id") int id)
	{
		 return a.deleteReview1Model(id);
	}
	@GetMapping(value="/getid1/{id}")
	public Supermarket getReview1Model(@PathVariable("id") int id)
	{
		return a.getReview1Model(id);
	}
	@GetMapping(value="/sortStudents/{sort}")
	public List<Supermarket> sortdetails(@PathVariable("sort") String id)
	{
		return a.sortdetails(id);
	}
	@GetMapping(value="/page/{offset}/{pagesize}")
	public List<Supermarket> getDetails(@PathVariable int offset,@PathVariable int pagesize)
	{
		return a.getpagingDetails1(offset,pagesize);
	}
	@GetMapping(value="/sortDetails22/{sort}")
	public List<Supermarket> sortDetails(@PathVariable("sort") String cost)
	{
		return a.getdetailscustomer(cost);
	}
	@GetMapping(value="/sortDetails11/{sort}")
	public List<Supermarket> sortDetails1(@PathVariable("sort") String cost)
{
		return a.details(cost);
	}
	@GetMapping(value="pagedetail/{offset}/{pagesize}")
	public List<Supermarket> getcustomerdetails(@PathVariable int offset,@PathVariable int pagesize)
	{
		return a.getcustdetails(offset,pagesize);
	}
	@GetMapping("/pagingdetail/{offset}/{pagesize}/{field}")
	public List<Supermarket>getcustomer(@PathVariable int offset,@PathVariable int pagesize,@PathVariable String field)
	{
		return a.getcustdetails1(offset,pagesize,field);
	}
	@GetMapping("/fetchByDept")
	public List<Supermarket> getStudentsByDept(@RequestParam String name)
	{
		return a.getStudentsByDept(name);
	}
	@GetMapping("/fetchByDept/{product_name}/{name}")
	public List<Supermarket> getStudentsByDept(@PathVariable String product_name,@PathVariable String name)
	{
		return a.getStudentsByDept(product_name,name);
	}
	@DeleteMapping("/deleteStudentByName/{name}")
    public String deleteStudentByName(@PathVariable String name)
    {
 	   int result = a.deleteStudentByName(name);
 	   if(result>0)
 		     return "Record deleted";
 	   else
 		     return "Problem occured while deleting";
    }
    @PutMapping("/updateStudentByName/{product_name}/{name}")
    public String updateStudentByName(@PathVariable String product_name,@PathVariable String name)
    {
 	   int res = a.updateStudentByName(product_name, name);
 	   if(res>0)
 		      return "Record updated";
 	   else
 		    return "Problem occured";
	
    }
    @GetMapping("/getDataCustomer")
	public List<Customer> getDataTournament()
	{
		return a.getDataCustomer();
	}
	@PutMapping("/saveDataCustomer")
	public Customer saveDataTournament(@RequestBody Customer data)
	{
		return a.saveDataCustomer(data);
	}
    }
