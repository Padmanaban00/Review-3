package com.review1.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.review1.demo.model.Supermarket;

public interface Review1Repository extends JpaRepository<Supermarket,Integer> {
	@Query("select s from Supermarket s where s.productname=?1 and s.name=?2")
    public List<Supermarket> getStudentsByProductname(String productname,String name);
   //named parameter
   @Query("select s from Supermarket s where s.name=:name")
   public List<Supermarket> getStudentsByName(String name);
	//DML
	@Modifying
	@Query("delete from Supermarket s where s.name=?1")
	public int deleteStudentByName(String name);
   @Modifying
   @Query("update Supermarket s set s.productname=?1 where s.name=?2")
   public int updateStudentByProductname(String productname,String name);
}
